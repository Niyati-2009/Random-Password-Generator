let inputSlider=document.getElementById("slider-length");
let sliderValue=document.getElementById("slider");
let save=document.getElementById("save");
let text=document.getElementById("text");
let refresh=document.getElementById("refresh");
let uppercase=document.getElementById("uppercase");
let lowercase=document.getElementById("lowercase");
let numbers=document.getElementById("numbers");
let symbols=document.getElementById("symbols");
let btn=document.getElementById("btn");
let strengthIndicator = document.getElementById("copy");
// show input slider value
sliderValue.textContent=inputSlider.value;
inputSlider.addEventListener('input',()=>{
    sliderValue.textContent=inputSlider.value;
});

btn.addEventListener('click',()=>{
    text.value=generatePassword();
    evaluateStrength(text.value);
});
let upperChars="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
let lowerChars="abcdefghijklmnopqrstuvwxyz";
let num="0123456789";
let allSymbols="!@#$%^&*/";
//for generator function:
function generatePassword(){
    let genPassword="";
    let allChars="";
   allChars+=lowercase.checked ? lowerChars:"";
   allChars+=uppercase.checked ? upperChars:"";
   allChars+=numbers.checked ? num:"";
   allChars+=symbols.checked ? allSymbols :"";

   if(allChars == "" || allChars.length==0){
    return genPassword;
   }
   let i=1;
   while(i<=inputSlider.value){
   genPassword += allChars.charAt(Math.floor(Math.random()*allChars.length));
   i++;
   }
   return genPassword;
}

function evaluateStrength(password){
    if (password.length < 8) {
      strengthIndicator.textContent = "Weak";
      strengthIndicator.style.backgroundColor = "yellow";
    } else if (password.length < 15) {
      strengthIndicator.textContent = "Good";
      strengthIndicator.style.backgroundColor = "orange";
    } else {
      strengthIndicator.textContent = "Very Strong";
      strengthIndicator.style.backgroundColor = " #68e868";
    }
  }
// copy password
save.addEventListener('click',()=>{
    if(text.value!=""){
    navigator.clipboard.writeText(text.value)
    // save.title="Password Copied";
    }
});
// for page refersh
function Refresh(){
    text.value='';
}
